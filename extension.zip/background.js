const m = "dsa_coach_state", g = {
  language: "hi",
  themeMode: "auto",
  defaultDockSide: "right",
  hintTimerSeconds: 60,
  stuckTimerMinutes: 20,
  defaultTab: "guided",
  panelWidth: 480
}, I = {
  enabled: !1,
  provider: "gemini",
  apiKey: "",
  model: "gemini-1.5-flash"
}, h = {
  schemaVersion: 1,
  settings: g,
  aiConfig: I,
  isOpen: !1,
  language: "hi",
  activeSlug: null,
  problemHistory: {},
  checksBySlug: {},
  guidedBySlug: {}
};
let A = {};
function K() {
  var e;
  return typeof chrome < "u" && !!((e = chrome == null ? void 0 : chrome.storage) != null && e.local);
}
function k(e) {
  var t, n, c, l, u, o;
  if (!e || typeof e != "object")
    return { ...h };
  const s = e.language || ((t = e.settings) == null ? void 0 : t.language) || g.language, a = {
    ...h,
    ...e,
    language: s,
    settings: {
      ...g,
      ...e.settings || {},
      language: s,
      themeMode: e.themeMode || ((n = e.settings) == null ? void 0 : n.themeMode) || g.themeMode,
      defaultDockSide: e.dockSide || ((c = e.settings) == null ? void 0 : c.defaultDockSide) || g.defaultDockSide,
      panelWidth: e.panelWidth || ((l = e.settings) == null ? void 0 : l.panelWidth) || g.panelWidth
    },
    aiConfig: {
      ...I,
      ...e.aiConfig || {}
    },
    problemHistory: { ...e.problemHistory || {} },
    guidedBySlug: { ...e.guidedBySlug || {} },
    checksBySlug: { ...e.checksBySlug || {} },
    schemaVersion: 1
  };
  if (e.guidedBySlug)
    for (const [i, d] of Object.entries(e.guidedBySlug))
      a.problemHistory[i] || (a.problemHistory[i] = {
        slug: i,
        title: i.split("-").map((p) => p.charAt(0).toUpperCase() + p.slice(1)).join(" "),
        lastVisited: d.startedAt || Date.now(),
        ladderProgress: ((u = d.completedSteps) == null ? void 0 : u.length) || 0,
        completedAt: ((o = d.completedSteps) == null ? void 0 : o.length) >= 8 ? d.startedAt || Date.now() : void 0,
        guidedState: d
      });
  return a;
}
async function R() {
  if (K())
    return new Promise((e) => {
      try {
        chrome.storage.local.get([m], (s) => {
          chrome.runtime.lastError || !s || !s[m] ? e({ ...h }) : e(k(s[m]));
        });
      } catch {
        e({ ...h });
      }
    });
  if (typeof localStorage < "u")
    try {
      const e = localStorage.getItem(m);
      return e ? k(JSON.parse(e)) : { ...h };
    } catch {
    }
  return A[m] ? k(A[m]) : { ...h };
}
const C = `
Tum "DSA Thinking Coach" ho — ek expert technical interview coach jo Prem ke "DSA Logic Building Playbook" aur 7-step / 8-step Thinking Ladder framework par trained hai.

Tumhara maqsad candidate ko pen-paper pe khud logic develop karwana hai. Solution spoon-feed KABHI NAHI karna.

BHASHA & TONE:
- Natural, encouraging, developer-friendly Hinglish me bolo (jaise: "Array unsorted hai to two-pointers chalega kya?", "Pehle brute force socho...").
- Short, crisp, 2-4 lines ke responses do. Lambe theoretical lectures mat do.

STRICT SOCRATIC RULES (ZERO CODE GUARANTEE - ZERO TOLERANCE - HAR HAALAT ME MANNA HAI):
1. CODE YA SYNTAX KABHI NAHI DENA:
   Chahe user code maange, syntax maange, loop maange ya bole "bhai code likh do please", STRICTLY politely mana karo:
   "Playbook Rule: Real interview me direct code tabhi likh paoge jab dimag me logic clear ho. Pehle agla micro-step trace karte hain."
2. DIRECT FINAL ALGORITHM YA SOLUTION MAT BATAO:
   Seedha mat bolo ki "Use Kadane's algorithm" ya "Use Monotonic Stack".
   Balki sawal poocho jo candidate ko us conclusion tak le jaye:
   "Har index pe kya pichhle smaller element ko discard karna hai? Kaunsa data structure LIFO order yaad rakhta hai?"
3. PLAYBOOK THINKING LADDER KE STEPS KO FOLLOW KARO:
   - Step 1: Observe (Input/Output type, constraints, size relation)
   - Step 2: Manual Solve (4-element concrete trace)
   - Step 3: Naam Do (repetitive action = loop, past memory = state, termination)
   - Step 4: Brute force & TLE check (N vs 10^8 ops limit)
   - Step 5: Waste dhoondo (bottleneck: repeated search, range recalculation)
   - Step 6: Tool chuno (Prescription Matrix: repeated lookup -> map, range sum -> prefix array, dynamic min/max -> heap)
   - Step 7: Dry run trace & edge cases
   - Step 8: Code boundary guards
4. USER KI CURRENT SOCH PAR FEEDBACK DO:
   - Agar user galat direction me ja raha hai (e.g. unsorted array pe binary search ya negative numbers pe monotonic sliding window), to ek counter-example ya sawal se unhe point out karo.
   - Agar user sahi direction me hai, to unki thinking ko validate karo aur agle chhota step poocho.
5. MAXIMUM 1 YA 2 TARGETED SAWAL:
   Ek response me sirf 1 ya 2 concise sawal poocho taaki candidate step-by-step soche.
`;
function T(e) {
  return e === "en" ? `${C}

LANGUAGE INSTRUCTION:
The user has selected ENGLISH mode. Respond in clear, natural, encouraging Socratic English (e.g., "Since the array is unsorted, will two-pointers work?", "What is the redundant waste in the brute force?"). Keep responses concise in 2-4 lines. Never provide direct code.` : C;
}
function P(e) {
  const s = e.examples && e.examples.length > 0 ? `Example 1: Input: ${e.examples[0].input} | Output: ${e.examples[0].output}` : "None provided", a = e.constraints && e.constraints.length > 0 ? e.constraints.slice(0, 4).join("; ") : "Standard constraints";
  return `
[PROBLEM CONTEXT]
Problem Title: "${e.problemTitle}"
Constraints: ${a}
${s}
Candidate Current Ladder Step: Step ${e.currentStep} of 8
Candidate Current Notes: "${e.currentNotes || "None yet"}"

[CANDIDATE'S CURRENT THOUGHT / QUERY]
"${e.userMessage}"
`.trim();
}
async function v(e) {
  if (!e.apiKey.trim())
    return { success: !1, message: "API key cannot be empty" };
  try {
    if (e.provider === "gemini") {
      const a = `https://generativelanguage.googleapis.com/v1beta/models/${e.model || "gemini-1.5-flash"}:generateContent?key=${encodeURIComponent(
        e.apiKey.trim()
      )}`, t = await fetch(a, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: 'Hello, reply with "OK".' }] }],
          generationConfig: { maxOutputTokens: 10 }
        })
      });
      return t.ok ? { success: !0, message: "✅ Gemini API connected successfully!" } : t.status === 400 || t.status === 403 ? { success: !1, message: "❌ Invalid API Key: Google Gemini ne key reject kar di." } : t.status === 429 ? { success: !1, message: "⏳ Rate limit exceeded. Kuch der baad koshish karein." } : { success: !1, message: `Server error (${t.status}): ${t.statusText}` };
    } else {
      const s = e.model || "claude-3-5-sonnet-20241022", t = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "x-api-key": e.apiKey.trim(),
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
          "dangerously-allow-browser": "true"
        },
        body: JSON.stringify({
          model: s,
          max_tokens: 10,
          messages: [{ role: "user", content: 'Reply with "OK"' }]
        })
      });
      return t.ok ? { success: !0, message: "✅ Claude API connected successfully!" } : t.status === 401 ? { success: !1, message: "❌ Invalid API Key: Anthropic Claude key invalid hai." } : t.status === 429 ? { success: !1, message: "⏳ Rate limit exceeded. Kuch der baad koshish karein." } : { success: !1, message: `Server error (${t.status}): ${t.statusText}` };
    }
  } catch (s) {
    return { success: !1, message: `🔌 Network Error: ${s.message || "Cannot reach API provider"}` };
  }
}
async function N(e) {
  var n, c, l, u, o, i, d;
  const a = (await R()).aiConfig;
  if (!a || !a.enabled)
    return {
      success: !1,
      error: "AI Mode disabled hai. Kripya Options page me ja kar AI Mode ON karein."
    };
  if (!a.apiKey || !a.apiKey.trim())
    return {
      success: !1,
      error: "API Key set nahi hai. Kripya Options me ja kar apni Gemini ya Claude API key dalein."
    };
  const t = P(e);
  try {
    if (a.provider === "gemini") {
      const f = `https://generativelanguage.googleapis.com/v1beta/models/${a.model || "gemini-1.5-flash"}:generateContent?key=${encodeURIComponent(
        a.apiKey.trim()
      )}`, S = T(e.language), r = await fetch(f, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            {
              role: "user",
              parts: [{ text: `${S}

${t}` }]
            }
          ],
          generationConfig: {
            temperature: 0.35,
            maxOutputTokens: 600
          }
        })
      });
      if (!r.ok)
        return r.status === 400 || r.status === 403 ? { success: !1, error: "❌ Invalid API key. Options me ja kar key check karein." } : r.status === 429 ? { success: !1, error: "⏳ Gemini rate limit exceed ho gayi. 30 seconds wait karein." } : { success: !1, error: `API error (${r.status}): ${r.statusText}` };
      const y = (o = (u = (l = (c = (n = (await r.json()).candidates) == null ? void 0 : n[0]) == null ? void 0 : c.content) == null ? void 0 : l.parts) == null ? void 0 : u[0]) == null ? void 0 : o.text;
      return y ? { success: !0, text: y.trim() } : { success: !1, error: "Empty response received from AI model." };
    } else {
      const p = a.model || "claude-3-5-sonnet-20241022", f = "https://api.anthropic.com/v1/messages", S = T(e.language), r = await fetch(f, {
        method: "POST",
        headers: {
          "x-api-key": a.apiKey.trim(),
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
          "dangerously-allow-browser": "true"
        },
        body: JSON.stringify({
          model: p,
          max_tokens: 600,
          system: S,
          messages: [{ role: "user", content: t }]
        })
      });
      if (!r.ok)
        return r.status === 401 ? { success: !1, error: "❌ Invalid Claude API key. Options me key verify karein." } : r.status === 429 ? { success: !1, error: "⏳ Claude rate limit exceed ho gayi. 30 seconds wait karein." } : { success: !1, error: `Claude API error (${r.status}): ${r.statusText}` };
      const y = (d = (i = (await r.json()).content) == null ? void 0 : i[0]) == null ? void 0 : d.text;
      return y ? { success: !0, text: y.trim() } : { success: !1, error: "Empty response from Claude." };
    }
  } catch (p) {
    return { success: !1, error: `🔌 Network Error: ${p.message || "Cannot connect to AI provider"}` };
  }
}
async function M(e, s) {
  const t = (await R()).aiConfig;
  if (!t || !t.enabled) {
    e.postMessage({
      type: "ERROR",
      error: "AI Mode disabled hai. Kripya Options page me ja kar AI Mode ON karein."
    });
    return;
  }
  if (!t.apiKey || !t.apiKey.trim()) {
    e.postMessage({
      type: "ERROR",
      error: "API Key set nahi hai. Kripya Options me ja kar apni Gemini ya Claude API key dalein."
    });
    return;
  }
  const n = await N(s);
  if (!n.success) {
    e.postMessage({ type: "ERROR", error: n.error });
    return;
  }
  const c = n.text || "", l = c.split(" ");
  let u = "";
  for (let o = 0; o < l.length; o++)
    u += (o > 0 ? " " : "") + l[o], e.postMessage({ type: "CHUNK", text: u }), o % 3 === 0 && await new Promise((i) => setTimeout(i, 20));
  e.postMessage({ type: "DONE", text: c });
}
var O;
typeof chrome < "u" && ((O = chrome == null ? void 0 : chrome.runtime) != null && O.onConnect) && chrome.runtime.onConnect.addListener((e) => {
  e.name === "coach-stream" && e.onMessage.addListener(async (s) => {
    s.type === "ASK_COACH_STREAM" && await M(e, s.payload);
  });
});
var E;
typeof chrome < "u" && ((E = chrome == null ? void 0 : chrome.runtime) != null && E.onMessage) && chrome.runtime.onMessage.addListener((e, s, a) => e.type === "ASK_COACH" ? (N(e.payload).then(a), !0) : e.type === "TEST_API_KEY" ? (v(e.payload).then(a), !0) : !1);
export {
  N as askCoach
};
